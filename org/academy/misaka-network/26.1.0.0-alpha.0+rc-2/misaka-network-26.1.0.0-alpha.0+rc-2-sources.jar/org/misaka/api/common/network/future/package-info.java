@NullMarked
package org.misaka.api.common.network.future;

import org.jspecify.annotations.NullMarked;