package org.misaka;

import com.mojang.logging.LogUtils;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.Connection;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppingEvent;
import org.misaka.api.common.network.NetworkManager;
import org.misaka.api.common.network.packet.Packet;
import org.misaka.api.common.network.packet.S2CPacket;
import org.misaka.api.server.network.future.FutureManagerServer;
import org.slf4j.Logger;

import static org.misaka.MisakaNetwork.shutdownExecutorService;

@EventBusSubscriber
public final class MisakaNetworkServer {
    public static final NetworkManager NETWORK_MANAGER = new NetworkManager();
    public static final FutureManagerServer FUTURE_MANAGER = new FutureManagerServer();
    private static final Logger LOGGER = LogUtils.getLogger();

    static {
        NETWORK_MANAGER.register(FUTURE_MANAGER);
    }

    public static <P extends Packet<ClientPacketListener, P>> void send(ServerPlayer player, P packet) {
        player.connection.send(new S2CPacket(packet));
    }

    public static <P extends Packet<ClientPacketListener, P>> void send(Connection connection, P packet) {
        connection.send(new S2CPacket(packet));
    }

    public static <P extends Packet<ClientPacketListener, P>> void send(ServerGamePacketListenerImpl listener, P packet) {
        listener.send(new S2CPacket(packet));
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        LOGGER.info("Dedicated server is stopping. Shutting down MisakaNetwork ExecutorService.");
        shutdownExecutorService();
    }

    private MisakaNetworkServer() {
    }
}
