package org.misaka;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.Identifier;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.neoforge.registries.NewRegistryEvent;
import org.misaka.api.common.network.NetworkSystem;
import org.misaka.internal.common.network.PacketTypes;
import org.slf4j.Logger;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static org.misaka.api.common.registries.MisakaNetworkRegistries.PACKET_TYPES;

@Mod(MisakaNetwork.MOD_ID)
public final class MisakaNetwork {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final ScheduledExecutorService EXECUTOR_SERVICE = Executors.newSingleThreadScheduledExecutor();
    public static final String MOD_ID = "misaka_network";

    public MisakaNetwork(IEventBus modEventBus) {
        PacketTypes.PACKET_TYPES.register(modEventBus);
        modEventBus.addListener(MisakaNetwork::onNewRegistry);
        modEventBus.addListener(MisakaNetwork::onCommonSetup);
    }

    public static Identifier location(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    private static void onNewRegistry(NewRegistryEvent event) {
        event.register(PACKET_TYPES);
    }

    private static void onCommonSetup(FMLCommonSetupEvent event) {
        event.enqueueWork(NetworkSystem::progressRegistry);
    }

    public static void shutdownExecutorService() {
        EXECUTOR_SERVICE.shutdown();
        try {
            if (!EXECUTOR_SERVICE.awaitTermination(5, TimeUnit.SECONDS)) {
                LOGGER.warn("ExecutorService did not terminate in 5 seconds. Forcing shutdown.");
                EXECUTOR_SERVICE.shutdownNow();
            }
        } catch (InterruptedException e) {
            LOGGER.error("Interrupted while waiting for ExecutorService to terminate. Forcing shutdown.");
            EXECUTOR_SERVICE.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}